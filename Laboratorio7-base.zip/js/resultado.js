// Para generar la información personal
let nombres = ["Jesús", "Alejandro", "Andrea", "Bruno", "Daniel", "Víctor", "Sofía", "Alonso", "Israel", "Mayra"]
let apellidos = ["Gayoso", "Morterero", "Montes", "Barrios", "Sánchez", "Alcabú", "Barrios", "Sáez", "Obregón", "Franco"]

// Locales de votación
let locales = ["Pontificia Universidad Católica del Perú",
  "Colegio San Agustín",
  "Campo de Marte",
  "Estadio Nacional",
  "Residencial San Felipe",
  "Estadio Daniel Alcides Carrión"
]

// Para generar la información si es miembro de mesa
let cargos = ["Presidente", "Secretario", "Tercer Miembro", "Primer Suplente", "Segundo Suplente", "Tercer Suplente"]
